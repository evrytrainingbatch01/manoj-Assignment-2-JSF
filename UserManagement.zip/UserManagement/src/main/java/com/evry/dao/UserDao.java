package com.evry.dao;

import java.sql.SQLException;
import java.util.List;

import com.evry.model.SelectedUserIds;
import com.evry.model.User;

/**
 * interface used to call user operations like add,update,delete the user also get all users 
 * @author manoj.kulakarni
 *
 */
public interface UserDao {
	
	/**
	 * get all user Details {@link User}
	 * @return list of users
	 * @throws SQLException 
	 */
	public List<User> getAllUsers() throws SQLException;
	/**
	 * add or update user with new data
	 * @param user data
	 * @return String value success or failure
	 */
	public boolean addOrUpdateUser(User user) throws SQLException;
	/**
	 * delete user using user id
	 * @param id is user id
	 * @return String success or failure
	 */
	public boolean deleteUser(int userId);
	
	/**
	 * delete selected users using user's ids
	 * @param ids are list of user's ids {@link SelectedUserIds}
	 * @return String success or failure
	 */
	public boolean deleteSelectedUsers(SelectedUserIds userIds);

	

}
