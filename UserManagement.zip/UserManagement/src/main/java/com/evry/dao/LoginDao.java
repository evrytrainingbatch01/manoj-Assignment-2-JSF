package com.evry.dao;

import java.util.List;

import org.hibernate.HibernateException;

import com.evry.CustomExceptions.DataNotFoundException;
import com.evry.model.Login;
import com.evry.model.User;

/**
 * interface used to call login verification of user
 * @author manoj.kulakarni
 *
 */
public interface LoginDao {

	/**
	 * loginVerification used to verify the user using login credentials
	 * @param login the bean object contains login credentials like email and password {@link Login}
	 * @return list of single user if email and password is valid otherwise list will be empty
	 * @throws HibernateException,DataNotFoundException
	 */
	public List<User> loginVerification(Login login) throws HibernateException,DataNotFoundException;

}
