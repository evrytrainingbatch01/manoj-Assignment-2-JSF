package com.evry.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evry.CustomExceptions.DataNotFoundException;
import com.evry.model.Login;
import com.evry.model.User;
import com.evry.util.HibernateUtil;
/**
 * LoginDaoImpl class implements the loginDao interface {@link LoginDao}.
 * Hit the database using HibernateUtil dependency {@link HibernateUtil} and verify the user
 * @author manoj.kulakarni
 *
 */
@Repository
public class LoginDaoImpl implements LoginDao {

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from HibernateUtil
	 * {@link HibernateUtil}
	 */
	@Autowired
	private HibernateUtil hibernateUtil;
	
	final static Logger logger= Logger.getLogger(LoginDaoImpl.class);
/*	final static  String STATUS_SUCCESS="success";
	final static String STATUS_INVALID_USER="invalidUser";
	final static String STATUS_UNAUTHORIZED_USER = "unauthorizedUser";*/
	/**
	 * verifying login credentials 
	 * @param login credentials 
	 * @return list of single user if email and password is valid otherwise list will be empty
	 *  @throws HibernateException and if given login credentials are null it will throw custom exception DataNotFoundException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<User> loginVerification(Login login) throws HibernateException,DataNotFoundException {
		Session session=null;
		 List<User> list=new ArrayList<User>();
		try {
			session= hibernateUtil.getSession();
			if(login.getEmail().toString()!=null && login.getPassword()!=null) {
				 Query query=session.createQuery("from User");//here persistent class name is User  
	        	    list=query.list();
			}else {
				throw new DataNotFoundException("Either Email or Password is null");//custom exception
			}
		}
		finally {
			session.close();
		}
		return list;
	}	

}
