package com.evry.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evry.model.SelectedUserIds;
import com.evry.model.User;
import com.evry.util.HibernateUtil;
/**
 * class implements the UserDao interface {@link UserDao}
 * Hit the database using HibernateUtil dependency {@link HibernateUtil} to do the user operations
 * @author manoj.kulakarni
 *
 */
@Repository
public class UserDaoImpl implements UserDao {

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences form HibernateUtil
	 * {@link HibernateUtil}
	 */
	@Autowired
	private HibernateUtil hibernateUtil;
	
	final static Logger logger=Logger.getLogger(UserDaoImpl.class);
	/**
	 * to get all user Details it will hit the database using HibernateUtil class
	 * @return list of users and it will throws SQLException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getAllUsers() throws SQLException{
		Session session = null;
		try {
			session = hibernateUtil.getSession();
			Query query = session.createQuery("from User");
			return query.list();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	/**
	 * add or update user with new data
	 * @param user data
	 * @return boolean true or false
	 */
	@Override
	public boolean addOrUpdateUser(User user) throws HibernateException {
		Session session = null;
		Transaction transaction = null;
		session = hibernateUtil.getSession();
		transaction = session.beginTransaction();
		try {
			if (user!=null && user.getEmailId()!=null) {
				session.saveOrUpdate(user);
				transaction.commit();
				return true;
			} else {
				//do custom exception
				return false;
				
			}
		}catch (NullPointerException e) {
			transaction.rollback();
			throw e;
		} 
		catch (HibernateException e) {
			transaction.rollback();
			throw e;
		}
	}
	
	
	/**
	 * delete user
	 * 
	 * @param id is user id
	 * @return boolean true or false
	 */
	@Override
	public boolean deleteUser(int userId) {
		Session session = null;
		Transaction transaction = null;
		boolean status = false;
		try {

			session = hibernateUtil.getSession();
			transaction = session.beginTransaction();
			User user = (User) session.load(User.class, userId);
			if (user != null) {
				session.delete(user);
				transaction.commit();
				status = true;
			} else {
				status = false;
			}
		} catch (Exception e) {
			transaction.rollback();
			status = false;
			e.getMessage();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return status;
	}
	/**
	 * delete selected users
	 * @param ids are list of user's ids {@link SelectedUserIds}
	 * @return boolean true or false
	 */
	@Override
	public boolean deleteSelectedUsers(SelectedUserIds userIds) {
		boolean status=false;
		for (Integer integer : userIds.getIds()) {
			status=deleteUser(integer);
		}
		return status;
	}
}
