package com.evry.util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
/**
 * class used for connect or disconnect the database using hibernate session 
 * @author manoj.kulakarni
 *
 */
@Component
public class HibernateUtil {
	
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	
	/**
	 * to get hibernate session 
	 * @return Session object
	 */
	public Session getSession() throws HibernateException
	{
		session=sessionFactory.openSession();
		return session;
	}
	/**
	 * close the SessionFactory 
	 */
	public  void closeSessionFactory()
	{
		sessionFactory.close();
	}

}
