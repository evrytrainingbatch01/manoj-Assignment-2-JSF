package com.evry.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evry.CustomExceptions.DataNotFoundException;
import com.evry.dao.LoginDao;
import com.evry.model.Login;
import com.evry.model.User;
import com.evry.util.ApplicationConstants;
/**
 * class implements the LoginService {@link LoginService} used for login verification of user
 * @author manoj.kulakarni
 *
 */
@Service
public class LoginServiceImpl implements LoginService {

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from LoginDao
	 *  {@link LoginDao}
	 */
	@Autowired
	LoginDao loginDao;

	final static Logger logger= Logger.getLogger(LoginServiceImpl.class);
	/**
	 * call the DAO layer LoginDao{@link LoginDao} for verifying the login credentials 
	 * @param login credentials
	 * @return map object contains entity with the key called "userEntity" and key status return string value
	 *  like success or invalidUser or unauthorized_User
	 */
	@Override
	public Map<String, Object> loginVerification(Login login) {
		Map<String,Object> map=new HashMap<String, Object>();
		try {
			
			List<User> list= loginDao.loginVerification(login);
			if(list.size()!=0) {
				for (User user : list) {
					String userEmail =  user.getEmailId();
					String userPassword =  user.getPassword();
					if(login.getEmail().equals(userEmail) && login.getPassword().equals(userPassword)) {
						map.put("userEntity", user);
						map.put("status", ApplicationConstants.STATUS_SUCCESS);
						break;
					}else {
						map.put("userEntity",  ApplicationConstants.STATUS_DUMMY_USER);
						map.put("status", ApplicationConstants.STATUS_INVALID_USER);
					}
				}
			}else {
				map.put("userEntity", ApplicationConstants.STATUS_DUMMY_USER);
				map.put("status", ApplicationConstants.STATUS_UNAUTHORIZED_USER);
			}
		} catch (HibernateException | DataNotFoundException |NullPointerException e) {
			map.put("userEntity", ApplicationConstants.STATUS_DUMMY_USER);
			map.put("status", ApplicationConstants.STATUS_INVALID_USER);
			logger.error("login verification failure because -s "+e);
		}
		return map;
	}

}
