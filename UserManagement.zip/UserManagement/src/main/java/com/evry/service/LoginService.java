package com.evry.service;

import java.util.Map;

import com.evry.model.Login;
/**
 *  interface  used to call login verification of user
 * @author manoj.kulakarni
 *
 */
public interface LoginService {
	/**
	 * loginVerification used to verify the user using login credentials
	 * @param login the bean object contains login credentials like email and password {@link Login}
	 * @return map object contains entity with the key called "userEntity" and key status return string value
	 *  like success or invalidUser or unauthorized_User
	 */
	public Map<String, Object> loginVerification(Login login);

}
