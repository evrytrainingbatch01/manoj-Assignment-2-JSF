package com.evry.service;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evry.CustomExceptions.DuplicateEntryException;
import com.evry.dao.UserDao;
import com.evry.model.SelectedUserIds;
import com.evry.model.User;
import com.evry.util.ApplicationConstants;

/**
 * class implements UserService {@link UserService} used to user operations like add,update,delete and get all users
 * @author manoj.kulakarni
 *
 */
@Service
public class UserServiceImpl implements UserService {
	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences
	 *  from UserDao {@link UserDao}
	 */
	@Autowired
	UserDao userDao;
	
     final static Logger logger=Logger.getLogger(UserServiceImpl.class.getName());
	/**
	 * get all user Details
	 * @return list of users
	 * @throws SQLException 
	 */
	@Override
	public List<User> getAllUsers() throws SQLException {
		return userDao.getAllUsers();
	}
	/**
	 * add or update user 
	 * @param user
	 * @return String value success or failure
	 * @throws DuplicateEntryException 
	 * @throws SQLException 
	 */
	@Override
	public String addOrUpdateUser(User user) throws HibernateException, SQLException, DuplicateEntryException {
		String status=null;
		
			logger.info("id-"+user.getId() +" name- "+user.getName()+" email- "+user.getEmailId()+" mobile- "+user.getMobileNo()+" password- "+user.getPassword());
			status = userDao.addOrUpdateUser(user)?ApplicationConstants.STATUS_SUCCESS:ApplicationConstants.STATUS_FAILURE ;
			return status;
	}
	/**
	 * delete user
	 * 
	 * @param id is user id
	 * @return String success or failure
	 */
	@Override
	public boolean deleteUser(int userId) {
		
			return userDao.deleteUser(userId);
	}
	

	/**
	 * delete selected users
	 * 
	 * @param ids are list of user's ids
	 * @return String success or failure
	 */
	@Override
	public boolean deleteSelectedUsers(SelectedUserIds userIds) {
		
		return userDao.deleteSelectedUsers(userIds);
	}
	/**
	 * handle the exception
	 * @param e
	 * @return String value either "Email_Id_Duplicate_Entry" or "Mobile_No_Duplicate_Entry"
	 */
	@Override
public String exceptionHandled(Exception e) {
	String status=ApplicationConstants.STATUS_FAILURE;
	if(e.getMessage().contains("Duplicate entry") && e.getMessage().contains("Email_Id") ) {
		status=ApplicationConstants.STATUS_DUPLICATE_EMAIL;
	}else if(e.getMessage().contains("Duplicate entry") && e.getMessage().contains("Mobile_No") ) {
		status=ApplicationConstants.STATUS_DUPLICATE_MOBILE;
	}else {
		status=ApplicationConstants.STATUS_FAILURE;
	}
	return status;
}
}
