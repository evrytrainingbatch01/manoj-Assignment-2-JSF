package com.evry.service;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;

import com.evry.CustomExceptions.DuplicateEntryException;
import com.evry.model.SelectedUserIds;
import com.evry.model.User;
/**
 * interface used to call user operations like add,update,delete the user also get all users 
 * @author manoj.kulakarni
 *
 */
public interface UserService {
	
	/**
	 * get all user Details {@link User}
	 * @return list of users
	 * @throws SQLException 
	 */
	public List<User> getAllUsers() throws SQLException;
	/**
	 * add or update user with new data
	 * @param user data
	 * @return String value success or failure
	 * @throws DuplicateEntryException 
	 * @throws SQLException 
	 * @throws HibernateException 
	 */
	public String addOrUpdateUser(User user) throws DuplicateEntryException, HibernateException, SQLException;
	
	/**
	 * delete user using user id
	 * @param id is user id
	 * @return String success or failure
	 */
	public boolean deleteUser(int userId);
	/**
	 * delete selected users using user's ids
	 * @param ids are list of user's ids {@link SelectedUserIds}
	 * @return String success or failure
	 */
	public boolean deleteSelectedUsers(SelectedUserIds userIds);
	/**
	 * handle the exception
	 * @param e
	 * @return String value either "Email_Id_Duplicate_Entry" or "Mobile_No_Duplicate_Entry"
	 */
	public String exceptionHandled(Exception e) ;
}
