package com.evry.controller;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.evry.CustomExceptions.DataNotFoundException;
import com.evry.CustomExceptions.DuplicateEntryException;
import com.evry.model.SelectedUserIds;
import com.evry.model.User;
import com.evry.service.UserService;
/**
 * class userController is the starting point for rest web service . if any request came from client related to user operations 
 * example : get all users, add, update or delete user  
 * @author manoj.kulakarni
 *
 */
@RestController
public class UserController {
	
	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from UserService
	 * {@link UserService}
	 */
	@Autowired
	UserService userService;
	
	final static Logger logger = Logger.getLogger(UserController.class);
	
	/**
	 * getAllUsers method is used to get all users from database
	 * @return list of users
	 */
	
	@GetMapping(value="/user",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<User> getAllUsers() {
		List<User> list = null;
		try {
			list= userService.getAllUsers();
			if(list.isEmpty()) {
				throw new DataNotFoundException("List Is Empty");
			}
		} catch (SQLException | NullPointerException e) {
			logger.error("UserController -  getAllUsers Method - "+e);
		}
		return list;
	}
	
	/**
	 * addUser method used to add new user 
	 * @param user is the bean object contains new user details {@link User}
	 * @return return string "success" or "failure"
	 */
	@PostMapping(value="/user")
	public String addUser(@RequestBody User user) {
		String status=null;
	
			try {
				status= userService.addOrUpdateUser(user);
			} catch (HibernateException | DuplicateEntryException | SQLException | NullPointerException e) {
				logger.info("Exception occured while adding user : "+e);
				status=	userService.exceptionHandled(e);
			}
		
		return status;
	}
	
	/**
	 * updateUser method used to update the existing user 
	 * @param user is the bean object contains updated data of existing user {@link User}
	 * @return return string "success" or "failure"
	 */
	
	@PutMapping(value="/user")
	public String updateUser(@RequestBody User user) {
		String status=null;
		try {
			status= userService.addOrUpdateUser(user);
		} catch (HibernateException | DuplicateEntryException | SQLException | NullPointerException e) {
			logger.info("Exception occured while updating user : "+e);
			status=userService.exceptionHandled(e);
		}
		return status;
	}
	
	/**
	 * delete single user Example: http://localhost:1010/UserManagement/user/?id=18
	 * @param userId
	 * @return true or false
	 * 
	 */
	@DeleteMapping(value="/user")
	public boolean deleteUser(@RequestParam(value="id") int userId) {
		return userService.deleteUser(userId);
	}
	/**
	 * delete multiple users Example: http://localhost:1010/UserManagement/user/deleteSelectedUser
	 * with body -  {"ids":[19,20]}
	 * @param userIds
	 * @return true or false
	 */
	@DeleteMapping(value="/user/deleteSelectedUser")
	public boolean deleteSelectedUsers(@RequestBody SelectedUserIds userIds) {
		return userService.deleteSelectedUsers(userIds);
	}

}
