package com.evry.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.evry.model.Login;
import com.evry.service.LoginService;
/**
 * 
 * @author manoj.kulakarni
 *class LoginController is the starting point for rest web service.it is used to verify the user 
 *
 */
@RestController
@RequestMapping("/login")
public class LoginController {
	
	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from LoginService
	 * {@link LoginService}
	 */
	@Autowired
	LoginService loginService;
	
	/**
	 * LoginVerification method used to verify the user with login credentials
	 * @param login is bean object contains login credentials like email id and password {@link Login}
	 * @return map object contains entity with the key called "userEntity" and key status return string value
	 *  like success or invalidUser or unauthorized_User
	 */
	@PostMapping(value="/verify")
	public Map<String, Object> loginVerification(@RequestBody Login login) {
		return loginService.loginVerification(login);
	}
}
