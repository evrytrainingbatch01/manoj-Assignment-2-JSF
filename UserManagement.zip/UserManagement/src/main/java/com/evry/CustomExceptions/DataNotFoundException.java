package com.evry.CustomExceptions;

public class DataNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public DataNotFoundException(String value){
		super(value);
	}
}
