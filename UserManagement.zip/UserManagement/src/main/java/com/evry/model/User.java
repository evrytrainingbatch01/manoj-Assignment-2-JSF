package com.evry.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * hibernate Entity class use to bind or mapping with database .
 * JPA annotation @Entity {@code javax.persistence.Entity} use to mapping with java Object with database table.
 * @table {@code javax.persistence.Table} refer the table User_Details in database
 * @author manoj.kulakarni
 *
 */

@Entity
@Table(name = "User_Details")
public class User implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;

	/**
	 * Specifies the primary key of an entity
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "User_Id")
	private int id;
	/**
	 *  specify the mapped column 'Name' for a persistent property or field
	 */
	@Column(name = "Name")
	private String name;
	/**
	 *  specify the mapped column 'Email_Id' for a persistent property or field
	 */
	@Column(name = "Email_Id", unique = true)
	private String emailId;
	/**
	 *  specify the mapped column 'Mobile_No' for a persistent property or field
	 */
	@Column(name = "Mobile_No", length = 20, unique = true)
	private Long mobileNo;
	/**
	 *  specify the mapped column 'Password' for a persistent property or field
	 */
	@Column(name = "Password", length = 20)
	private String password;

	/**
	 * default contractor of User
	 */
	public User() {
		super();
	}

	/**
	 * Parameterized contractor for User
	 * @param id
	 * @param name
	 * @param emailId
	 * @param mobileNo
	 * @param password
	 */
	public User(int id, String name, String emailId, Long mobileNo, String password) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.password = password;
	}

	/**
	 * get the value of private member id
	 * @return integer
	 */
	public int getId() {
		return id;
	}
	/**
	 * set the value of private member
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * get the value of private member name
	 * @return String
	 */
	public String getName() {
		return name;
	}
	/**
	 * set the value of private member
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * get the value of private member emailId
	 * @return String
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * set the value of private member
	 * @param emailId
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * get the value of private member mobileNo
	 * @return Long
	 */
	public Long getMobileNo() {
		return mobileNo;
	}
	/**
	 * set the value of private member
	 * @param mobileNo
	 */
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * get the value of private member password
	 * @return String
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * set the value of private member
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * override method from Object class to convert to String
	 */
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", emailId=" + emailId + ", mobileNo=" + mobileNo + ", password="
				+ password + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + id;
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (id != other.id)
			return false;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

}
