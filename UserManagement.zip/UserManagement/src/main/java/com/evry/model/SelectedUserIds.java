package com.evry.model;

import java.util.List;
/**
 * class used for binding value like list of ids from consumer side
 * @author manoj.kulakarni
 *
 */
public class SelectedUserIds {
	
	/**
	 * list {@code java.util.List} of integer
	 */
	private List<Integer> ids;

	/**
	 * default contractor 
	 */
	public SelectedUserIds() {
		super();
	}
	/**
	 * Parameterized contractor 
	 * @param ids
	 */
	public SelectedUserIds(List<Integer> ids) {
		super();
		this.ids = ids;
	}

	/**
	 * get the list of ids from private member ids
	 * @return list {@code java.util.List} of integer
	 */
	public List<Integer> getIds() {
		return ids;
	}
	/**
	 * set the list of ids from private member ids
	 * @param ids
	 */ 
	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}

	/**
	 * override method from Object class to convert to String
	 */
	@Override
	public String toString() {
		return "SelectedUserIds [ids=" + ids + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ids == null) ? 0 : ids.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectedUserIds other = (SelectedUserIds) obj;
		if (ids == null) {
			if (other.ids != null)
				return false;
		} else if (!ids.equals(other.ids))
			return false;
		return true;
	}
	
	

}
