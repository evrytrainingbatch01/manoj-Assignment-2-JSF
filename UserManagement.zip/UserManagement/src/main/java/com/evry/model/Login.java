package com.evry.model;

import java.io.Serializable;
/**
 * POJO class used to binding  the values and transferring the value via network
 * @author manoj.kulakarni
 *
 */
public class Login implements Serializable,Cloneable{
	
	private static final long serialVersionUID = 1L;
	/**
	 * to check login email property is required 
	 */
	private String email;
	/**
	 * to check login password property required
	 */
	private String password;
	
	/**
	 * default contractor of login
	 */
	public Login() {
		super();
	}
	/**
	 * Parameterized contractor for login
	 * @param email 
	 * @param password
	 */
	public Login(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	/**
	 * get the value of private member email
	 * @return String 
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * set the value of private member
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * get the value of private member password
	 * @return String
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * set the value of private member
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * override method from Object class to convert to String
	 */
	@Override
	public String toString() {
		return "Login [email=" + email + ", password=" + password + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Login other = (Login) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}
	
	

}
