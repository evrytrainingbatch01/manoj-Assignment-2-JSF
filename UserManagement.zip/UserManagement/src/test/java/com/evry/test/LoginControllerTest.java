package com.evry.test;

import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.evry.controller.LoginController;
import com.evry.model.Login;
import com.evry.model.User;
import com.evry.service.LoginService;
import com.evry.util.ApplicationConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Specifies to test the login credentials and if user is present it will return
 * user entity with status
 * 
 * @RunWith attaches a runner with the test class to initialize the test data
 * @author manoj.kulakarni
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginControllerTest {
	/**
	 * MockMvc is the main entry point for server-side Spring MVC test support.
	 * Perform a request and return a type that allows chaining further actions,
	 * such as asserting expectations, on the result.
	 */
	private MockMvc mockMvc;

	@Mock
	LoginService loginServiceMock;

	@InjectMocks
	LoginController loginController;

	@Before
	public void setUp() {

		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(loginController).build();
	}

	/**
	 * test for login verify with valid data and return the map object contains user
	 * entity and the status
	 * 
	 * @throws Exception
	 */
	@Test
	public void testloginVerification_success() throws Exception {
		Login login = new Login("manoj@gmail.com", "123456");
		Map<String, Object> map = new HashMap<String, Object>();
		User user = new User(1, "manoj", "manoj@gmail.com", 9035669251L, "123456");
		map.put("userEntity", user);
		map.put("status", ApplicationConstants.STATUS_SUCCESS);
		when(loginServiceMock.loginVerification(login)).thenReturn(map);
		mockMvc.perform(
				post("/login/verify").contentType(MediaType.APPLICATION_JSON_VALUE).content(asJsonString(login)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status", is(ApplicationConstants.STATUS_SUCCESS)))
				.andExpect(jsonPath("$.userEntity.id", is(1))).andExpect(jsonPath("$.userEntity.name", is("manoj")))
				.andExpect(jsonPath("$.userEntity.emailId", is("manoj@gmail.com")));
	}
	/**
	 * test for login verify with invalid data and return the map object contains user
	 * entity and the status
	 * 
	 * @throws Exception
	 */
	@Test
	public void testloginVerification_failure() throws Exception {
		Login login = new Login("manoj@gmail.com", "123456");
		Map<String, Object> map = new HashMap<String, Object>();
		User user = new User(0, "null", null, null, null);
		map.put("userEntity", user);
		map.put("status", ApplicationConstants.STATUS_FAILURE);
		when(loginServiceMock.loginVerification(login)).thenReturn(map);
		mockMvc.perform(
				post("/login/verify").contentType(MediaType.APPLICATION_JSON_VALUE).content(asJsonString(login)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.status", is(ApplicationConstants.STATUS_FAILURE)))
				.andExpect(jsonPath("$.userEntity.name", is("null")));
	}

	/**
	 * converting Object to jsonString
	 * 
	 * @param obj
	 * @return string
	 */
	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
