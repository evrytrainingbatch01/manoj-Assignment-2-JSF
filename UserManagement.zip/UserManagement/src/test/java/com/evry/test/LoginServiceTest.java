package com.evry.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.evry.dao.LoginDao;
import com.evry.model.Login;
import com.evry.model.User;
import com.evry.service.LoginService;
import com.evry.service.LoginServiceImpl;
import com.evry.util.ApplicationConstants;
/**
 * Specifies to test the login credentials and if user is present it will return user entity with status 
 * 
 * @author manoj.kulakarni
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class LoginServiceTest {

	/**
	 * Dependency mock for login service
	 */
	@Mock
	LoginDao loginDaoMock;
	/**
	 * from LoginServiceImpl calls the loginVerification method
	 */
	@InjectMocks
	LoginService loginService=new LoginServiceImpl();
	
	
	/**
	 * Test the login credentials using stub for returning excepted value
	 */
	@Test
	public void testLoginVerification() {
		List<User> users = Arrays.asList(new User(1, "manoj", "manoj@gmail.com", 9035669251L, "123456"));
		Login login=new Login("manoj@gmail.com","123456");
		when(loginDaoMock.loginVerification(login)).thenReturn(users);
		assertEquals(getAcceptmap("happyflow"), loginService.loginVerification(login));
		
	}
	/**
	 * Test the login credentials using stub , when emailId or password is wrong or null it will  returns excepted value like map object.
	 */
	@Test
	public void testLoginVerification_WithWrongPassword() {
		List<User> users = Arrays.asList(new User(1, "manoj", "manoj@gmail.com", 9035669251L, "123456"));
		Login login=new Login("manoj@gmail.com","11");
		
		when(loginDaoMock.loginVerification(login)).thenReturn(users);
		assertEquals(getAcceptmap("wrongPassword"), loginService.loginVerification(login));
		
	}
	/**
	 * general code to create mock object
	 * @param type
	 * @return map {@code java.util.Map}
	 */
	private Map<String, Object> getAcceptmap(String type){
		Map<String, Object> acceptmap=new HashMap<String, Object>();
		if(type.equals("happyflow")) {
			User user=new User(1,"manoj","manoj@gmail.com",9035669251L,"123456");
			acceptmap.put("userEntity", user);
			acceptmap.put("status", ApplicationConstants.STATUS_SUCCESS);
			
		}else if(type.equals("wrongPassword")) {
			acceptmap.put("userEntity", ApplicationConstants.STATUS_DUMMY_USER);
			acceptmap.put("status", ApplicationConstants.STATUS_INVALID_USER);
		}
		return acceptmap;
	}
	
	
	
}
