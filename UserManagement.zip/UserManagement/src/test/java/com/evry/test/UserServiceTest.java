package com.evry.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.HibernateException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.evry.CustomExceptions.DuplicateEntryException;
import com.evry.dao.UserDao;
import com.evry.model.SelectedUserIds;
import com.evry.model.User;
import com.evry.service.UserServiceImpl;
import com.evry.util.ApplicationConstants;

/**
 * @RunWith attaches a runner with the test class to initialize the test data
 * @author manoj.kulakarni
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	/**
	 * @Mock annotation is used to create the mock object to be injected
	 * Dependency mock for user service to do the operation 
	 */
	@Mock
	UserDao userDaoMock;
	/**
	 * @InjectMocks annotation is used to create and inject the mock object
	 * Inject the userServiceImpl for calling methods
	 */
	@InjectMocks
	UserServiceImpl userServiceImpl;

	/**
	 * test to get the all users
	 * @throws SQLException
	 */
	@Test
	public final void testGetAllUsers() throws SQLException {
		List<User> users = Arrays.asList(new User(1, "manoj", "manoj@gmail.com", 9035669251L, "123456"),
				new User(2, "dinesh", "dinesh@gmail.com", 9908778909L, "123456"));

		when(userDaoMock.getAllUsers()).thenReturn(users);
		assertEquals(users, userServiceImpl.getAllUsers());
	}
	/**
	 * test to add a new user with the happy flow means without exception or error
	 * @throws SQLException
	 * @throws HibernateException
	 * @throws DuplicateEntryException
	 */
	@Test
	public final void testaddOrUpdateUser_addNewUser() throws SQLException, HibernateException, DuplicateEntryException {
		User newUser=new User(0,"akilash","akilash@gmail.com",9090909000L,"123456");
		checkAddOrUpdateUser(newUser,true);
	}
	/**
	 * test to add a new user but in given object include the  duplicate Email,so the output excepted is false
	 * @throws SQLException
	 * @throws HibernateException
	 * @throws DuplicateEntryException
	 */
	@Test
	public final void testaddOrUpdateUser_addNewUser_duplicateEmail() throws SQLException, HibernateException, DuplicateEntryException {
		User newUser=new User(0,"manoj","manoj@gmail.com",9090909000L,"123456");
		checkAddOrUpdateUser(newUser,false);
	}
	/**
	 * test to add a new user but in given object include the  duplicate MobileNum,so the output excepted is false
	 * @throws SQLException
	 * @throws HibernateException
	 * @throws DuplicateEntryException
	 */
	@Test
	public final void testaddOrUpdateUser_addNewUser_duplicateMobileNum() throws SQLException, HibernateException, DuplicateEntryException {
		User newUser=new User(0,"akilash","akilash@gmail.com",9035669251L,"123456");
		checkAddOrUpdateUser(newUser,false);
	}
	/**
	 * test to update the exists user ,so the output excepted is true
	 * @throws SQLException
	 * @throws HibernateException
	 * @throws DuplicateEntryException
	 */
	@Test
	public final void testaddOrUpdateUser_updateUser() throws SQLException, HibernateException, DuplicateEntryException {
		User updateUser=new User(1,"manoj","manoj@gmail.com",9090909000L,"123456");//mobile number updating
		checkAddOrUpdateUser(updateUser,true);
	}
	/**
	 * test to update the exists user but in given object include the  duplicate Email,so the output excepted is false
	 * @throws SQLException
	 * @throws HibernateException
	 * @throws DuplicateEntryException
	 */
	@Test
	public final void testaddOrUpdateUser_updateUser_duplicateEmail() throws SQLException, HibernateException, DuplicateEntryException {
		User updateUser=new User(1,"manoj","dinesh@gmail.com",9090909000L,"123456");//mobile number updating
		checkAddOrUpdateUser(updateUser,false);
	}
	/**
	 * test to update the exists user but in given object include the  duplicate MobileNum,so the output excepted is false
	 * @throws SQLException
	 * @throws HibernateException
	 * @throws DuplicateEntryException
	 */
	@Test
	public final void testaddOrUpdateUser_updateUser_duplicateMobileNum() throws SQLException, HibernateException, DuplicateEntryException {
		User updateUser=new User(1,"manoj","dinesh@gmail.com",9090909000L,"123456");
		checkAddOrUpdateUser(updateUser,false);
	}
	/**
	 * to check the stub return the true or false 
	 * @param user will be new user while adding user or else exists user for updating user
	 * @param returntype true or false for return the stub
	 * @throws HibernateException
	 * @throws SQLException
	 * @throws DuplicateEntryException
	 */
	private void checkAddOrUpdateUser( User user,boolean returntype) throws HibernateException, SQLException, DuplicateEntryException {
		when(userDaoMock.addOrUpdateUser(user)).thenReturn(returntype);
		if(returntype) {
			assertEquals(ApplicationConstants.STATUS_SUCCESS, userServiceImpl.addOrUpdateUser(user));
		}else {
			assertEquals(ApplicationConstants.STATUS_FAILURE, userServiceImpl.addOrUpdateUser(user));
		}
	}
	
	/**
	 * test for delete user with valid input
	 */
	@Test
	public final void testdeleteUser() {
		when(userDaoMock.deleteUser(1)).thenReturn(true);
		assertEquals(true, userServiceImpl.deleteUser(1));
	}
	/**
	 * test for delete user with invalid user id
	 */
	@Test
	public final void testdeleteUser_invalidUserId() {
		when(userDaoMock.deleteUser(2)).thenReturn(false);
		assertEquals(false, userServiceImpl.deleteUser(2));
	}
	/**
	 * test for selected users can delete with valid ids
	 * stub return the true value
	 */
	@Test
	public final void testdeleteSelectedUsers() {
		List<Integer> ids = new ArrayList<Integer>();
		ids.add(1);
		ids.add(3);
		SelectedUserIds userids=new SelectedUserIds();
		userids.setIds(ids);
		when(userDaoMock.deleteSelectedUsers(userids)).thenReturn(true);
		assertEquals(true, userServiceImpl.deleteSelectedUsers(userids));
	}
	/**
	 * tets for selected users can delete with invalid ids
	 * stub return the false value
	 */
	
	@Test
	public final void testdeleteSelectedUsers_invalidUserIds() {
		List<Integer> ids = new ArrayList<Integer>();
		ids.add(70);
		ids.add(71);
		SelectedUserIds userids=new SelectedUserIds();
		userids.setIds(ids);
		when(userDaoMock.deleteSelectedUsers(userids)).thenReturn(false);
		assertEquals(false, userServiceImpl.deleteSelectedUsers(userids));
	}
	
}
