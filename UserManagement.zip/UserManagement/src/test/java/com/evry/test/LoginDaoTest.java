package com.evry.test;

import org.junit.Test;


public class LoginDaoTest {
	

	@Test
	public void testloginVerification_success() {
		//Login login =  new Login("manoj@gmail.com","123456");
	//	List<User> users=Arrays.asList(new User(1,"manoj","manoj@gmail.com",9035669251L,"123456"));
		//List<User> dbresult=loginDao.loginVerification(login);
	//	Assert.assertEquals(dbresult.isEmpty(), users.isEmpty());
	}

}
