package com.evry.test;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.evry.CustomExceptions.DuplicateEntryException;
import com.evry.controller.UserController;
import com.evry.model.SelectedUserIds;
import com.evry.model.User;
import com.evry.service.UserService;
import com.evry.util.ApplicationConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @RunWith attaches a runner with the test class to initialize the test data
 * @author manoj.kulakarni
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class UserControllerTest {
	/**
	 * MockMvc is the main entry point for server-side Spring MVC test support.
	 * Perform a request and return a type that allows chaining further actions,
	 * such as asserting expectations, on the result.
	 */
	private MockMvc mockMvc;
	/**
	 * @Mock annotation is used to create the mock object to be injected Dependency
	 *       mock for userController to do the operation
	 */
	@Mock
	private UserService userService;
	/**
	 * @InjectMocks annotation is used to create and inject the mock object Inject
	 *              the userController for calling methods
	 */
	@InjectMocks
	private UserController userController;

	/**
	 * @Before annotation is used to initialized the method before calling test
	 *         method initialized the object mockMvc using MockMvcBuilders
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
	}

	/**
	 * test for get all users from service
	 * 
	 * @throws Exception
	 */
	@Test
	public void testgetAllUsers() throws Exception {
		List<User> users = Arrays.asList(new User(1, "manoj", "manoj@gmail.com", 9035669251L, "123456"),
				new User(2, "dinesh", "dinesh@gmail.com", 9908778909L, "123456"));
		when(userService.getAllUsers()).thenReturn(users);
		mockMvc.perform(get("/user").content(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$", hasSize(2))).andExpect(jsonPath("$[0].id", is(1)))
				.andExpect(jsonPath("$[0].name", is("manoj"))).andExpect(jsonPath("$[1].id", is(2)))
				.andExpect(jsonPath("$[1].name", is("dinesh")));
		verify(userService, times(1)).getAllUsers();
		verifyNoMoreInteractions(userService);
	}

	/**
	 * test for add new user successfully
	 * 
	 * @throws Exception
	 */
	@Test
	public void testaddUser() throws Exception {
		User user = new User(1, "ram", "ram@gmail.com", 9035669909L, "123456");
		when(userService.addOrUpdateUser(user)).thenReturn(ApplicationConstants.STATUS_SUCCESS);
		mockMvc.perform(post("/user").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE).content(asJsonString(user)))
				.andExpect(status().isOk());
		verify(userService, times(1)).addOrUpdateUser(user);
		verifyNoMoreInteractions(userService);

	}

	/**
	 * test for add new user with the duplicate entry and exception handled by
	 * custom exception
	 * 
	 * @throws Exception
	 */
	@Test
	public void testaddUser_failure() throws Exception {
		User user = new User(1, "ram", "manoj@gmail.com", 9035669909L, "123456");
		when(userService.addOrUpdateUser(user)).thenThrow(new DuplicateEntryException("Duplicate entry"))
				.thenReturn(ApplicationConstants.STATUS_FAILURE);
		mockMvc.perform(post("/user").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE).content(asJsonString(user)))
				.andExpect(status().isOk());
		verify(userService, times(1)).addOrUpdateUser(user);
	}

	/**
	 * test for update the exist user successfully
	 * 
	 * @throws Exception
	 */
	@Test
	public void testupdateUser() throws Exception {
		User user = new User(1, "ram", "ram@gmail.com", 9035669909L, "123456");
		when(userService.addOrUpdateUser(user)).thenReturn(ApplicationConstants.STATUS_SUCCESS);
		mockMvc.perform(put("/user").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE).content(asJsonString(user)))
				.andExpect(status().isOk());
		verify(userService, times(1)).addOrUpdateUser(user);

	}

	/**
	 * test for update exist user with the duplicate entry and exception handled by
	 * custom exception
	 * 
	 * @throws Exception
	 */
	@Test
	public void testupdateUser_failure() throws Exception {
		User user = new User(1, "ram", "manoj@gmail.com", 9035669909L, "123456");
		when(userService.addOrUpdateUser(user)).thenThrow(new DuplicateEntryException("Duplicate entry"))
				.thenReturn(ApplicationConstants.STATUS_FAILURE);
		mockMvc.perform(put("/user").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE).content(asJsonString(user)))
				.andExpect(status().isOk());
		verify(userService, times(1)).addOrUpdateUser(user);

	}

	/**
	 * test for delete user based on user id
	 * 
	 * @throws Exception
	 */
	@Test
	public void testdeleteUser() throws Exception {
		User user = new User(1, "ram", "ram@gmail.com", 9035669909L, "123456");
		when(userService.deleteUser(user.getId())).thenReturn(true);
		mockMvc.perform(delete("/user?id=" + user.getId()).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
		verify(userService, times(1)).deleteUser(user.getId());
		verifyNoMoreInteractions(userService);

	}

	/**
	 * test for delete user with invalid user id
	 * 
	 * @throws Exception
	 */
	@Test
	public void testdeleteUser_failure() throws Exception {
		when(userService.deleteUser(2)).thenReturn(false);
		mockMvc.perform(delete("/user?id=" + 2).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
		verify(userService, times(1)).deleteUser(2);
		verifyNoMoreInteractions(userService);
	}

	/**
	 * test for delete the selected user
	 * 
	 * @throws Exception
	 */
	@Test
	public void testdeleteSelectedUsers() throws Exception {
		User user1 = new User(1, "ram", "manoj@gmail.com", 9035669909L, "123456");
		User user2 = new User(2, "manoj", "manoj@gmail.com", 9035669251L, "123456");
		List<Integer> list = Arrays.asList(user1.getId(), user2.getId());
		SelectedUserIds userIds = new SelectedUserIds(list);
		when(userService.deleteSelectedUsers(userIds)).thenReturn(false);
		mockMvc.perform(delete("/user/deleteSelectedUser").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(userIds))).andExpect(status().isOk());

	}

	/**
	 * test for delete the selected user with invalid user ids
	 * 
	 * @throws Exception
	 */
	@Test
	public void testdeleteSelectedUsers_failure() throws Exception {
		List<Integer> list = Arrays.asList(0, 80);
		SelectedUserIds userIds = new SelectedUserIds(list);
		when(userService.deleteSelectedUsers(userIds)).thenReturn(false);
		mockMvc.perform(delete("/user/deleteSelectedUser").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(userIds))).andExpect(status().isOk());

	}

	/**
	 * converting Object to jsonString
	 * 
	 * @param obj
	 * @return string
	 */
	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
