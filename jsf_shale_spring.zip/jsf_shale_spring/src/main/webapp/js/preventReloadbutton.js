/**
 * prevent Reload button ex: click on F5 ,ctrl+R, right Click -> Reload
 */
	document.onkeydown = function(e) {

		var key;
		if (window.event) {
			key = event.keyCode
		} else {
			var unicode = e.keyCode ? e.keyCode : e.charCode
			key = unicode
		}
		switch (key) {//event.keyCode
		case 116: //F5 button
			//alert("F5");
			event.returnValue = false;
			key = 0; //event.keyCode = 0;
			return false;
		case 82: //R button
			//alert("ctrl+R");
			if (event.ctrlKey) {
				//alert("11");
				event.returnValue = false;
				key = 0; //event.keyCode = 0;
				return false;
			}
		}
	}

	document.oncontextmenu = function(e) {
		return false;
	}