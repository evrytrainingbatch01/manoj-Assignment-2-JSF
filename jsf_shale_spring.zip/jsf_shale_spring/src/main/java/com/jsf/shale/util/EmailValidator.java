package com.jsf.shale.util;

import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
/**
 * class implements the Validator {@link Validator}  specify the validation as given pattern.
 * @author manoj.kulakarni
 *
 */
public class EmailValidator implements Validator{

	/**
	 * validate method use to validate the Email with the given pattern.it uses the JSF specified FacesContext and UIComponent. 
	 * Using of these Objects it will match with given value and gives the String value if specify the <h:messages/> in JSF page or 
	 * if given value is mismatch  it will throw an Exception called ValidatorException
	 */
	public void validate(FacesContext context, UIComponent component,
            Object value) throws ValidatorException {
        String enteredEmail = (String) value;
        Pattern p = Pattern.compile(".+@.+\\.[a-z]+");
        Matcher m = p.matcher(enteredEmail);
        boolean matchFound = m.matches();
        if (!matchFound) {
            FacesMessage message = new FacesMessage();
			ResourceBundle backendText = context.getApplication().getResourceBundle(context, "EMS");
			String msg = backendText.getString("invalidErrorEmail");
            message.setSummary(msg);
            throw new ValidatorException(message);
        }
    }

}
