package com.jsf.shale;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.component.html.HtmlDataTable;
import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

import com.jsf.shale.controller.UserController;
import com.jsf.shale.util.ApplicationConstants;
import com.jsf.shale.util.DTOComparator;
/**
 * class User acts as Backing Bean for JSF as configure in face-config.xml file and model for spring .
 *  used to bind the value and transfer the data via network
 * @author manoj.kulakarni
 *
 */
public class User {
	/**
	 * properties of user
	 */
	private int id;
	private String name;
	private String emailId;
	private Long mobileNo;
	private String password;

	/**
	 * to get the control to call the next layer 
	 */
	private UserController userController;
	
	/**
	 * list  of users will binding to this variable
	 */
	private List<User> userList = new ArrayList<User>();

	/**
	 * to display the no data if {@code list<User>} is empty
	 */
	private boolean nodata = false;

	/**
	 * to edit User
	 */
	private boolean editable;
	private User editUserData;
	
	// Pagination-
	HtmlDataTable dataTable = new HtmlDataTable();

	// Sorting datatable.
	private String sortField = null;
	private boolean sortAscending = true;

	// Search data.
	private User searchExample = this;
	private boolean searchMode;

	// Select multiple rows.
	private Map<Long, Boolean> selectedIds = new HashMap<Long, Boolean>();
	private List<Integer> selectedDataList;
	
	final static Logger logger=Logger.getLogger(User.class);
	
	/**
	 * setter and getter methods for private  variables 
	 */

	public List<Integer> getSelectedDataList() {
		return selectedDataList;
	}

	public void setSelectedDataList(List<Integer> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}

	public Map<Long, Boolean> getSelectedIds() {
		return selectedIds;
	}

	public void setSelectedIds(Map<Long, Boolean> selectedIds) {
		this.selectedIds = selectedIds;
	}

	public User getSearchExample() {
		return searchExample;
	}

	public void setSearchExample(User searchExample) {
		this.searchExample = searchExample;
	}

	public boolean isSearchMode() {
		return searchMode;
	}

	public void setSearchMode(boolean searchMode) {
		this.searchMode = searchMode;
	}

	public User getEditUserData() {
		return editUserData;
	}

	public void setEditUserData(User editUserData) {
		this.editUserData = editUserData;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public UserController getUserController() {
		return userController;
	}

	public void setUserController(UserController userController) {
		this.userController = userController;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;

	}

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	public boolean isSortAscending() {
		return sortAscending;
	}

	public void setSortAscending(boolean sortAscending) {
		this.sortAscending = sortAscending;
	}

	public boolean isNodata() {
		return nodata;
	}

	public void setNodata(boolean nodata) {
		this.nodata = nodata;
	}

	public String getRegsitrationDetails() {
		return ApplicationConstants.STATUS_SUCCESS;

	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;

	}

	public void setUserList(List<User> user) {
		this.userList = user;
	}

	public List<User> getUserList() {

		if (userList == null) {
			loadDataList(); // Preload by lazy loading.
		}
		return userList;
	}

	/**
	 * Retrieve and store data: load data list.
	 */
	private void loadDataList() {

		try {
			userList = userController.getAllUsers();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	public String employeeDetails() {
		loadDataList();
		return "list";
	}

	/**
	 * add user or register new user
	 * 
	 * @return String value success or failure
	 */

	public String addUser() {
		String status = userController.addUser(this);
		if (status.equals(ApplicationConstants.STATUS_SUCCESS)) {
			resetForm();
		}
		existsMsg(status);
		return status;
	}

	/**
	 * add new Employee after logged in
	 * 
	 * @return String value success or failure
	 */

	public String addEmployee() {
		String status = userController.addUser(this);
		if (status.equals(ApplicationConstants.STATUS_SUCCESS)) {
			loadDataList();
			LocaleChange.lacalemsg("actionAddEmployeeSuccess");
			resetForm();
		}else if(status.equals(ApplicationConstants.STATUS_FAILURE)) {
			LocaleChange.lacalemsg("actionWentWrong");
		}
		existsMsg(status);
		return status;

	}
	/**
	 * reset the form 
	 */
	private  void resetForm() {
		this.name = "";
		this.emailId = "";
		this.mobileNo = null;
		this.password = "";
		
	}
	
	/**
	 * if any email or mobile number exists and try to add or update that
	 *  its display the message like already exist.
	 * @param status
	 */
	private void existsMsg(String status) {
		if(status.equals("Email_Id_Duplicate_Entry")) {
			LocaleChange.lacalemsg("actionAddEmployeeEmailExitsError");
		}else if(status.equals("Mobile_No_Duplicate_Entry")) {
			LocaleChange.lacalemsg("actionAddEmployeeMobileExitsError");
		
		}
	}

	
	// edit table

	public String editAction(User user) {
		this.setEditUserData(user);
		return ApplicationConstants.STATUS_SUCCESS;
	}

	/**
	 * submit the update details
	 * 
	 * @param user
	 *            update data
	 * @return String success or failure
	 */
	public String editUserRecord(User user) {
		String status = userController.UpdateUser(user);
		if (status.equals(ApplicationConstants.STATUS_SUCCESS)) {
			LocaleChange.lacalemsg("actonUpdateSuccess");
		}
		existsMsg(status);
		return status;

	}

	/**
	 * delete user
	 * 
	 * @param id
	 *            is user id
	 * @return String success or failure
	 */

	public String deleteUserRecord(int id) {
		String status = userController.DeleteUser(id);
		if (status.equals(ApplicationConstants.STATUS_SUCCESS)) {
			LocaleChange.lacalemsg("actionDeleteSuccess");
			loadDataList();
		}
		return status;
	}

	// pagination

	public void pageFirst() {
		dataTable.setFirst(0);
	}

	public void pagePrevious() {
		dataTable.setFirst(dataTable.getFirst() - dataTable.getRows());
	}

	public void pageNext() {
		dataTable.setFirst(dataTable.getFirst() + dataTable.getRows());
	}

	public void pageLast() {
		int count = dataTable.getRowCount();
		int rows = dataTable.getRows();
		dataTable.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// get the current page number
	public int getCurrentPage() {
		int rows = dataTable.getRows();
		int first = dataTable.getFirst();
		int count = dataTable.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// get the total no of pages
	public int getTotalPages() {
		int rows = dataTable.getRows();
		int count = dataTable.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}

	/**
	 * Sorting datatable: sort data list.
	 * 
	 * @param event
	 *            The action event.
	 */
	public void sortDataList(ActionEvent event) {
		String sortFieldAttribute = getAttribute(event, "sortField");

		if (sortField != null && sortField.equals(sortFieldAttribute)) {
			sortAscending = !sortAscending;
		} else {
			sortField = sortFieldAttribute;
			sortAscending = true;
		}

		// Sort results.
		if (sortField != null) {
			Collections.sort(getUserList(), new DTOComparator(sortField, sortAscending));
		}
	}

	/**
	 * Get attribute value from the component using action event and attribute name.
	 * 
	 * @param event
	 *            The action event.
	 * @param name
	 *            The attribute name.
	 */
	private static String getAttribute(ActionEvent event, String name) {
		String value = (String) event.getComponent().getAttributes().get(name);
		return value;
	}

	// search List by name
	public static List<User> searchName(List<User> persons, String name) {
		List<User> persons1 = new ArrayList<User>();
		for (User user : persons) {
			if (user.getEmailId().toLowerCase().contains(name) || user.getName().contains(name) ) {
				persons1.add(user);
			}
		}
		return persons1;
	}

	public void filterByName(String name) {
		if (name.equals("")) {
			searchExample = new User();
			loadDataList();
		}
		if (name != null) {
			List<User> per = searchName(getUserList(), name);
			userList = per;
			if (per.isEmpty()) {
				logger.info("list is empty");
				userList = per;
			}
		}
	}

	// select multiple row delete operation

	/**
	 * Select multiple rows: get selected data items.
	 * 
	 */
	@SuppressWarnings("unlikely-arg-type")
	public String getSelectedItems() {
		logger.info("selectedIds" + selectedIds);
		// Get selected items.
		selectedDataList = new ArrayList<Integer>();
		for (User dataItem : getUserList()) {
			if (selectedIds.get(dataItem.getId()) != null) {
				if (selectedIds.get(dataItem.getId()).booleanValue()) {
					selectedDataList.add(dataItem.getId());
					selectedIds.remove(dataItem.getId()); // Reset.
				}

			} else {
				break;
			}
		}

		String status = userController.deleteSelectedUsers(selectedDataList);
		if (status.equals(ApplicationConstants.STATUS_SUCCESS)) {
			LocaleChange.lacalemsg("actionSelectempDeleteSuccess");
			loadDataList();
		} else if (status.equals("list_empty")) {
			LocaleChange.lacalemsg("actionSelectempDelectError");
			status = ApplicationConstants.STATUS_SUCCESS;
			loadDataList();
		}
		return status;
	}
	
}
