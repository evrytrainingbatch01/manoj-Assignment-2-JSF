package com.jsf.shale.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
/**
 * class implements the Filter {@link Filter}
 * <p>A filter is an object that performs 
 * filtering tasks on either the request to a resource (a servlet or static content), or on the response
 * from a resource, or both.</p>
 * 
 * @author manoj.kulakarni
 *
 */
@WebFilter(filterName = "AuthFilter", urlPatterns = { "*.jsf" })
public class AuthorizationFilter implements Filter {

	public AuthorizationFilter() {
	}

	/**
	 * <p>Called by the web container
     * to indicate to a filter that it is being placed into service.</p>
	 */
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	final static Logger logger=Logger.getLogger(AuthorizationFilter.class);
	
/**
 * * The <code>doFilter</code> method of the Filter is called by the
     * container each time a request/response pair is passed through the
     * chain due to a client request for a resource at the end of the chain.
     * The FilterChain passed in to this method allows the Filter to pass
     * on the request and response to the next entity in the chain.
     * Here if client request other then login.jsf without logging into
     *  application means without creation of a session it will redirect to login.jsf
 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) {
		try {
			HttpServletRequest reqt = (HttpServletRequest) request;
			HttpServletResponse resp = (HttpServletResponse) response;
			HttpSession ses = reqt.getSession(false);

			String reqURI = reqt.getRequestURI();
			
			if (reqURI.indexOf("/login.jsf") >= 0
					|| (ses != null && ses.getAttribute("username") != null)
					|| reqURI.indexOf("/public/") >= 0
					|| reqURI.contains("javax.faces.resource"))
				chain.doFilter(request, response);
			else {
				if (reqURI.indexOf("/registration_form.jsf") >= 0) {
					chain.doFilter(request, response);
				}else {
					resp.sendRedirect(reqt.getContextPath() + "/pages/login.jsf");
				}
				}
		} catch (IOException e) {
			logger.info("AuthorizationFilter - doFilter- "+e);
		}catch (ServletException e) {
			logger.info("AuthorizationFilter - doFilter- "+e);
		}
	}

	/**
	 * <p>Called by the web container 
     * to indicate to a filter that it is being
     * taken out of service.</p>
	 */
	public void destroy() {

	}
}