package com.jsf.shale.util;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
/**
 * class implements the Validator {@link Validator}  specify the validation as to confirm password logic.
 * @author manoj.kulakarni
 *
 */
public class PasswordValidator implements Validator {

	/**
	 *  method validate or matches the password as taken from JSF page and confirm password as @param value .
	 *  if both are matches it will return otherwise it will throw the Exception called ValidatorException
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {

		String confirmPassword = (String) value;
		 UIInput confirmComponent = (UIInput) context.getViewRoot().findComponent("regform:password");
		String password = (String) confirmComponent.getValue();
		if (password == null || password.isEmpty() || confirmPassword == null || confirmPassword.isEmpty()) {
			return; // Let required="true" do its job.
		}

		if (!confirmPassword.equals(password)) {
			ResourceBundle backendText = context.getApplication().getResourceBundle(context, "EMS");
			String msg = backendText.getString("actionConfirmPassword");
		    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,msg, msg);
		    throw new ValidatorException(message);
		  }

	}

}
