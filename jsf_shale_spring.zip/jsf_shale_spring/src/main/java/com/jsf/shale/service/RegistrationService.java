package com.jsf.shale.service;

import com.jsf.shale.User;

/**
 * interface used to add a new user
 * @author manoj.kulakarni
 *
 */
public interface RegistrationService {
	/**
	 * add new user 
	 * @param user {@link User } contains new user Details
	 * @return String value "success" or "failure"
	 */
	public String addUser(User user);

}
