package com.jsf.shale.controller;

import java.util.List;

import com.jsf.shale.User;

/**
 * interface used to call user operations like update,delete the user also get all users 
 * @author manoj.kulakarni
 *
 */
public interface UserController {

	/**
	 * get all user Details {@link User}
	 * @return list of users
	 */
	public List<User> getAllUsers();
	/**
	 * add new user 
	 * @param user {@link User } contains new user Details
	 * @return String value "success" or "failure"
	 */
	public String addUser(User user);
	/**
	 * update user data using new data of existing user
	 * @param update user data {@link User}
	 * @return String success or failure
	 */
	public String UpdateUser(User user);
	/**
	 * delete user using user id
	 * @param id is user id
	 * @return String success or failure
	 */
	public String DeleteUser(int id);
	/**
	 * delete selected users using user's ids
	 * @param ids are list of user's ids 
	 * @return String success or failure
	 */
	public String deleteSelectedUsers(List<Integer> ids);
}
