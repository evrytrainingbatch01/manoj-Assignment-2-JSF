package com.jsf.shale.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.jsf.shale.Login;
import com.jsf.shale.service.LoginService;

/**
 * class implements LoginController {@link LoginController} used for login verification of user
 * @author manoj.kulakarni
 *
 */
@Controller
public class LoginCotrollerImpl implements LoginController{
	
	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from LoginService
	 */
	@Autowired
	private LoginService loginService;
	
	/**
	 * verifying login credentials
	 * @param login input values from client
	 * @return map object contains entity with the key called "userEntity" and key status return string value
	 *  like success or invalidUser or unauthorized_User
	 */
	public Map<String, String> verify(Login login) {

		return loginService.verify(login);
	}

}
