package com.jsf.shale;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

/**
 * class acts like backing bean for JSF, used to do the internationalization 
 * @author manoj.kulakarni
 *
 */
public class LocaleChange implements Serializable{

	private static final long serialVersionUID = 1L;
	/**
	 * use the variable to bind the values from JSF 
	 */
	   private String locale;
	   /**
	    * the static map object for i18n.
	    */
	   private static Map<String,String> countries;
	      static {
	      
	      countries = new LinkedHashMap<String,String>();
	      countries.put("English", "en");
	      countries.put("Sweden","sv");
	   }

	      /**
	       * get value of private member countries
	       * @return countries of type Map
	       */
	   public Map<String, String> getCountries() {
	      return countries;
	   }
	   /**
	    * get value of private member locale
	    * @return String value
	    */
	   public String getLocale() {
	      return locale;
	   }
	   /**
	    * set value of private member locale
	    * @param locale
	    */
	   public void setLocale(String locale) {
	      this.locale = locale;
	   }
	   /**
	    *  the value change from JSF, the lacale variable value will change from this method using map object countries 
	    * @param e is a value change event listener if any value changes from JSF it will listen
	    */
	   public void changeLanguage(ValueChangeEvent e) {
	      String newLocaleValue = e.getNewValue().toString();
	      for (Entry<String, String> entry : countries.entrySet()) {
	         if(entry.getValue().toString().equals(newLocaleValue)) {
	            FacesContext.getCurrentInstance()
	               .getViewRoot().setLocale(new Locale(newLocaleValue));         
	         }
	      }
	   }
	   /**
	    * any message bind to JSF using FacesContext 
	    * @param message
	    */
	   public static void lacalemsg(String message) {
			FacesContext context = FacesContext.getCurrentInstance();
			String msg = context.getApplication().getResourceBundle(context, "EMS").getString(message);
			 context.addMessage(null, new FacesMessage(msg));
		}
}
