package com.jsf.shale;

import java.io.Serializable;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.jsf.shale.controller.LoginController;
import com.jsf.shale.util.ApplicationConstants;
import com.jsf.shale.util.SessionUtils;

/**
 * class Login acts as Backing Bean for JSF as configure in face-config.xml file and model for spring .
 *  used to bind the value and transfer the data via network
 * @author manoj.kulakarni
 *
 */
public class Login implements Serializable {

	private static final long serialVersionUID = 1L;
	/**
	 * response status for JSF
	 */
	/*final static  String STATUS_SUCCESS="success";
	final static String STATUS_INVALID_USER="invalidUser";
	final static String STATUS_UNAUTHORIZED_USER = "unauthorizedUser";*/
	/**
	 * private variable email is bind the value from its setter or getter methods
	 */
	private String email;
	/**
	 * private variable password is bind the value from its setter or getter methods
	 */
	private String password;
	/**
	 * to get the control to call the next layer 
	 */
	private LoginController logincontrol;

	/**
	 * default contractor
	 */
	public Login() {
		super();
	}
	/**
	 * parameterized contractor
	 */
	public Login(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	/**
	 * get the and bind with JSF
	 * @return LoginController object
	 */
	public LoginController getLogincontrol() {
		return logincontrol;
	}
	/**
	 * setthe value and bind with JSF
	 * @param logincontrol
	 */
	public void setLogincontrol(LoginController logincontrol) {
		this.logincontrol = logincontrol;
	}

	/**
	 * get the value of private member email and it will bind with JSF
	 * @return String value
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * set the value of private member email and it will bind with JSF
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * get the value of private member password and it will bind with JSF
	 * @return String value
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * set the value of private member password and it will bind with JSF
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Verifying the login credentials
	 * @return String value success ,invalideUser and unauthorizedUser
	 */
	public String verify() {
		Map<String ,String> map = logincontrol.verify(this);
		
		String status= map.get("status").toString();
		if (status.equals(ApplicationConstants.STATUS_INVALID_USER)) {
			LocaleChange.lacalemsg("actionLoginInvalid");
		} else if (status.equals(ApplicationConstants.STATUS_UNAUTHORIZED_USER)) {
			LocaleChange.lacalemsg("actionLoginUnauthorized");
		} else if(status.equals(ApplicationConstants.STATUS_SUCCESS)){
			HttpSession session = SessionUtils.getSession();
			session.setAttribute("username", map.get("name"));
		}
		return status;
	}
	/**
	 * when click on logout , the event come to this method and it will invalidate session
	 * @return String value "login" for redirected to login.jsf
	 */
	// logout event, invalidate session
	public String logout() {
		HttpSession session = SessionUtils.getSession();
		session.invalidate();
		return "login";
	}
}
