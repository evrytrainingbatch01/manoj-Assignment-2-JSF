package com.jsf.shale.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.jsf.shale.User;
import com.jsf.shale.service.RegistrationService;
import com.jsf.shale.service.UserService;

/**
 * class implements UserController {@link UserController} used to do the user operations
 *  like add.update,delete and get all users
 * @author manoj.kulakarni
 *
 */
@Controller
public class UserControllerImpl implements UserController{

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences 
	 * from RegistrationService {@link RegistrationService}
	 */
	@Autowired
	private RegistrationService registrationService;
	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences 
	 * from UserService
	 */
	@Autowired
	private UserService userService;
	/**
	 * get all user records
	 * 
	 * @return list of users
	 */
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}
	/**
	 * update user
	 * 
	 * @param update
	 *            user data
	 * @return String success or failure
	 */
	public String UpdateUser(User user) {
		return userService.UpdateUser(user);
	}
	/**
	 * delete user
	 * 
	 * @param id
	 *            is user id
	 * @return String success or failure
	 */
	public String DeleteUser(int id) {
		return userService.DeleteUser(id);
	}
	
	/**
	 * delete selected users
	 * 
	 * @param ids
	 *            are list of user's ids
	 * @return String success or failure
	 */
	public String deleteSelectedUsers(List<Integer> ids) {
		return userService.deleteSelectedUsers(ids);
	}
	/**
	 * add User or register user 
	 * @param user data
	 * @return String success or failure 
	 */
	public String addUser(User user) {
	return registrationService.addUser(user);	
	}
	

}
