package com.jsf.shale.util;

public class ApplicationConstants {

	public final static String STATUS_SUCCESS = "success";
	public final static String STATUS_INVALID_USER="invalidUser";
	public final static String STATUS_UNAUTHORIZED_USER = "unauthorizedUser";
	public final static String STATUS_DUPLICATE_EMAIL="Email_Id_Duplicate_Entry";
	public final static String STATUS_DUPLICATE_MOBILE="Mobile_No_Duplicate_Entry";
	public final static String STATUS_FAILURE="failure";
	
}
