package com.jsf.shale.util;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;

/**
 * Provides a way to identify a user across more than one page
 * request or visit to a Web site and to store information about that user. 
 
 * @author manoj.kulakarni
 *
 */
@Component
public class SessionUtils {
/**
 *  The servlet container uses HttpSession {@code javax.servlet.http.HttpSession;} interface to create a session between an HTTP 
 * client and an HTTP server. The session persists for a specified time period, 
 * across more than one connection or page request from the user. 
 * A session usually corresponds to one user, who may visit a site many times.
 * The server can maintain a session in many ways such as using cookies or rewriting URLs.
 * @return HttpSession object
 */
	public static HttpSession getSession() {
		return (HttpSession) FacesContext.getCurrentInstance()
				.getExternalContext().getSession(false);
	}

	public static HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance()
				.getExternalContext().getRequest();
	}
/**
 * using HttpSession can create username and saved in that session. if you want to get the usename we can call this method 
 * @return String value
 */
	public static String getUserName() {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance()
				.getExternalContext().getSession(false);
		return session.getAttribute("username").toString();
	}
/**
 * using HttpSession can create userid and saved in that session. if you want to get the userid we can call this method 
 * @return String value
 */
	public static String getUserId() {
		HttpSession session = getSession();
		if (session != null)
			return (String) session.getAttribute("userid");
		else
			return null;
	}
}
