package com.jsf.shale.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jsf.shale.User;
import com.jsf.shale.util.ApplicationConstants;
import com.jsf.shale.util.RestApiService;

/**
 * class implements RegistrationService {@link RegistrationService} use to add new user
 * annotation @service {@code org.springframework.stereotype.Service} to register the bean as a service layer.
 * configure the file apiProperties to get rest API URL.
 * @author manoj.kulakarni
 *
 */
@Service
@Configuration
@PropertySource("classpath:/apiProperties.properties")
public class RegistrationServiceImpl implements RegistrationService {

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from Environment
	 *  and use to get rest API URL from apiProperties file
	 */
	@Autowired
	private Environment env;

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from RestApiService 
	 * to call rest API call 
	 */
	@Autowired
	RestApiService restAPIcall;
	
	/*final static String STATUS_FAILURE="failure";*/
	/**
	 * add User or register user 
	 * @param user data
	 * @return String success or failure 
	 */
	public String addUser(User user) {
		String status = ApplicationConstants.STATUS_FAILURE;
		try {
			String url = env.getProperty("baseURL") + env.getProperty("userURL");
			status = restAPIcall.addUser(user, url);
			
		} catch (Exception e) {
			status = ApplicationConstants.STATUS_FAILURE;
		}
		return status;
	}

}
