package com.jsf.shale.service;

import java.util.Map;

import com.jsf.shale.Login;

/**
 * interface specify the verification of user while logging in
 * @author manoj.kulakarni
 *
 */
public interface LoginService {
	/**
	 *  used to verify the user using login credentials
	 * @param login the bean object contains login credentials like email and password {@link Login}
	 * @return map object contains entity with the key called "userEntity" and key status return string value
	 *  like success or invalidUser or unauthorized_User
	 */
	public Map<String, String> verify(Login login);
}

