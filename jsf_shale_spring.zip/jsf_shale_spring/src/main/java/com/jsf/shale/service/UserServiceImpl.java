package com.jsf.shale.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jsf.shale.User;
import com.jsf.shale.util.ApplicationConstants;
import com.jsf.shale.util.RestApiService;
/**
 * class implements UserService {@link UserService} used to do the user operations like update,delete and get all users
 * annotation @Service {@code org.springframework.stereotype.Service} to register the bean as a service layer.
 * configure the file apiProperties to get rest API URL.
 * @author manoj.kulakarni
 *
 */
@Service
@Configuration
@PropertySource("classpath:/apiProperties.properties")
public class UserServiceImpl implements UserService {

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from Environment
	 *  and use to get rest API URL from apiProperties file
	 */
	@Autowired
	private Environment env;

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from RestApiService 
	 * to call rest API call 
	 */
	@Autowired
	RestApiService restAPIcall;
	
	/*final static String STATUS_SUCCESS = "success";
	final static String STATUS_FAILURE = "failure";*/
	
	/**
	 * get all user records
	 * 
	 * @return list of users
	 */
	public List<User> getAllUsers() {
		List<User> list = new ArrayList<User>();
		try {
			String url = env.getProperty("baseURL") + env.getProperty("userURL");
			list = restAPIcall.getAllUserList(url);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * update user
	 * 
	 * @param update
	 *            user data
	 * @return String success or failure
	 */
	public String UpdateUser(User user) {

		String status = ApplicationConstants.STATUS_FAILURE;
		try {
			String url = env.getProperty("baseURL") + env.getProperty("userURL");
			status = restAPIcall.updateUser(user, url);
		} catch (Exception e) {
			status = ApplicationConstants.STATUS_FAILURE;
		}
		return status;

	}

	/**
	 * delete user
	 * 
	 * @param id
	 *            is user id
	 * @return String success or failure
	 */
	public String DeleteUser(int id) {

		String url = env.getProperty("baseURL") + env.getProperty("userURL") + "/?id=" + id;
		try {
			boolean value = restAPIcall.deleteUser(url);
			if (value) {
				return ApplicationConstants.STATUS_SUCCESS;
			} else {
				return ApplicationConstants.STATUS_FAILURE;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ApplicationConstants.STATUS_FAILURE;
		}
	}

	/**
	 * delete selected users
	 * 
	 * @param ids
	 *            are list of user's ids
	 * @return String success or failure
	 */
	public String deleteSelectedUsers(List<Integer> ids) {

		String url = env.getProperty("baseURL") + env.getProperty("deleteSelectedUsersURL");
		try {

			if (ids.isEmpty()) {
				return "list_empty";
			} else {

				boolean value = restAPIcall.deleteSelectedUsers(ids, url);
				if (value) {
					return ApplicationConstants.STATUS_SUCCESS;
				} else {
					return ApplicationConstants.STATUS_FAILURE;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			return ApplicationConstants.STATUS_FAILURE;
		}
	}

}
