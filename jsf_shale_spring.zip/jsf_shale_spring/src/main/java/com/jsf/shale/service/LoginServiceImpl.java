package com.jsf.shale.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.jsf.shale.Login;
import com.jsf.shale.util.RestApiService;

/**
 * class implements LoginService {@link LoginService} used for login verification of user
 * annotation @Service {@code org.springframework.stereotype.Service} to register the bean as a service layer.
 * configure the file apiProperties to get rest API URL.
 * @author manoj.kulakarni
 *
 */
@Service
@Configuration
@PropertySource("classpath:/apiProperties.properties")
public class LoginServiceImpl implements LoginService {

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from Environment
	 *  and use to get rest API URL from apiProperties file
	 */
	@Autowired
	private Environment env;

	/**
	 * annotation {@code org.springframework.beans.factory.annotation.Autowired} to get all dependences from RestApiService 
	 * to call rest API call 
	 */
	@Autowired
	RestApiService restAPIcall;

	/**
	 * verifying login credentials
	 * @param login input values from client
	 * @return map object contains entity with the key called "userEntity" and key status return string value
	 *  like success or invalidUser or unauthorized_User
	 */
	public Map<String,String> verify(Login login) {
		Map<String , String> map=new HashMap<String,String>();
		try {
			String url = env.getProperty("baseURL") + env.getProperty("loginVerifyURL");
		 map = restAPIcall.loginVerify(login, url);
			
		} catch (Exception e) {
			map.put("status", "failure");
		}
		return map;
	}

}
