package com.jsf.shale.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jsf.shale.Login;
import com.jsf.shale.User;

/**
 * to call the rest web services through apache HttpClient .
 * 
 * @author manoj.kulakarni
 */
@Component
public class RestApiService {

	final static Logger logger = Logger.getLogger(RestApiService.class);

	/**
	 * constants http method name
	 */
	public static final String METHOD_GET="GET";
	public static final String METHOD_POST="POST";
	public static final String METHOD_PUT="PUT";
	public static final String METHOD_DELETE="DELETE";
	
	/**
	 * get all users
	 * 
	 * @param url
	 * @return list of users
	 */
	public List<User> getAllUserList(String url) {
		List<User> userList = null;
		try {
			String jsonResponse = sendRequest(url, METHOD_GET, null, null, null);
			ObjectMapper mapper = new ObjectMapper();
			userList = mapper.readValue(jsonResponse, new TypeReference<List<User>>() {
			});

		} catch (ClientProtocolException ex) {
			logger.info("RestApiService - getAllUserList - "+ex);

		} catch (IOException ex) {
			logger.info("RestApiService - getAllUserList - "+ex);


		}
		return userList;
	}

	/**
	 * add user method
	 * 
	 * @param user
	 *            as new user data
	 * @param url
	 * @return string value success or failure
	 */
	public String addUser(User user, String url) {
		String status = null;
		try {
			status = sendRequest(url, METHOD_POST, user, null, null);

		} catch (ClientProtocolException ex) {
			logger.info("RestApiService - addUser - "+ex);

		} catch (IOException ex) {
			logger.info("RestApiService - addUser - "+ex);

		}

		return status;
	}

	/**
	 * update user method
	 * 
	 * @param user
	 *            as update user data
	 * @param url
	 * @return string value success or failure
	 */
	public String updateUser(User user, String url) {
		String status = null;
		try {
			status = sendRequest(url, METHOD_PUT, user, null, null);

		} catch (ClientProtocolException ex) {
			logger.info("RestApiService - updateUser - "+ex);

		} catch (IOException ex) {
			logger.info("RestApiService - updateUser - "+ex);

		}

		return status;
	}

	/**
	 * delete selected users
	 * 
	 * @param url
	 * @return boolean value true or false
	 */
	public boolean deleteSelectedUsers(List<Integer> ids, String url) {
		String status = null;
		try {
			status = sendRequest(url, METHOD_DELETE, null, null, ids);
		} catch (ClientProtocolException ex) {
			logger.info("RestApiService - deleteSelectedUsers - "+ex);

		} catch (IOException ex) {
			logger.info("RestApiService - deleteSelectedUsers - "+ex);

		}

		return Boolean.parseBoolean(status);
	}

	/**
	 * verify the login credentials
	 * 
	 * @param login
	 *            contains user name and password
	 * @param url
	 * @return string value success or invalid User
	 */

	public Map<String, String> loginVerify(Login login, String url) {
		String status = null;
		Map<String, String> map1 = new HashMap<String, String>();
		try {
			status = sendRequest(url, METHOD_POST, null, login, null);
			logger.info("status-- " + status);
			status = status.substring(15, status.length() - 1); // remove curly brackets
			String[] keyValuePairs = status.replaceAll("\"", "").split(","); // split the string to create key-value
																				// pairs
			Map<String, String> map = new HashMap<String, String>();
			for (String pair : keyValuePairs) {
				String[] entry = pair.split(":");
				map.put(entry[0], entry[1]);
			}
			map1.put("name", map.get("name"));
			map1.put("status", map.get("status"));

		} catch (ClientProtocolException ex) {
			logger.info("RestApiService - loginVerify - "+ex);

		} catch (IOException ex) {
			logger.info("RestApiService - loginVerify - "+ex);

		}
		return map1;
	}

	/**
	 * delete user
	 * 
	 * @param url
	 * @return boolean value true or false
	 */
	public boolean deleteUser(String url) {
		String status = null;
		try {
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpDelete httpRequest = new HttpDelete(url);
			HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
			logger.info("status code is:" + httpResponse.getStatusLine().getStatusCode());
			status = EntityUtils.toString(httpResponse.getEntity());

		} catch (ClientProtocolException ex) {
			logger.info("RestApiService - deleteUser - "+ex);

		} catch (IOException ex) {
			logger.info("RestApiService - deleteUser - "+ex);

		}

		return Boolean.parseBoolean(status);
	}

	/**
	 * specify to call rest api using apache HttpClient . here based on the method
	 * type it will create HttpUriRequest object
	 * 
	 * @param url
	 *            -to call rest api
	 * @param method
	 *            - based on this method of type string it will create
	 *            HttpUriRequest object example method is "POST" it will create
	 *            HttpPost object
	 * @param user
	 *            - want to add or update user then user object {@link User} will
	 *            came from client
	 * @param login
	 *            - want to verify the user then login object is useful
	 *            {@link Login}
	 * @param ids
	 *            - want to delete selected users then go for ids of type array of
	 *            integer
	 * @return String value depends on which operation called
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	private String sendRequest(String url, String method, User user, Login login, List<Integer> ids)
			throws ClientProtocolException, IOException {
		HttpUriRequest httpRequest = null;

		if (method.equals("GET")) {
			// get all users
			httpRequest = new HttpGet(url);
		} else if (method.equals("POST")) {
			// login verify
			if (login != null) {
				httpRequest = new HttpPost(url);
				JSONObject json = new JSONObject();
				json.put("email", login.getEmail());
				json.put("password", login.getPassword());
				((HttpPost) httpRequest).setEntity(new StringEntity(json.toString(), "UTF-8"));
			} else {

				// add new Use
				httpRequest = new HttpPost(url);
				JSONObject json = new JSONObject();
				json.put("name", user.getName());
				json.put("emailId", user.getEmailId());
				json.put("mobileNo", user.getMobileNo());
				json.put("password", user.getPassword());
				((HttpPost) httpRequest).setEntity(new StringEntity(json.toString(), "UTF-8"));
			}

		} else if (method.equals("PUT")) {
			// update user details
			httpRequest = new HttpPut(url);
			JSONObject json = new JSONObject();
			json.put("id", user.getId());
			json.put("name", user.getName());
			json.put("emailId", user.getEmailId());
			json.put("mobileNo", user.getMobileNo());
			json.put("password", user.getPassword());
			((HttpPut) httpRequest).setEntity(new StringEntity(json.toString(), "UTF-8"));
		} else if (method.equals("DELETE")) {
			// delete selected uses
			httpRequest = new HttpDeleteWithBody(url);
			JSONObject json = new JSONObject();
			json.put("ids", ids);
			((HttpDeleteWithBody) httpRequest).setEntity(new StringEntity(json.toString(), "UTF-8"));
		}
		CloseableHttpClient httpClient = HttpClients.createDefault();
		httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
		httpRequest.addHeader("charset", "UTF-8");
		HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
		logger.info("http Response is:" + httpResponse.toString());
		logger.info("status code is:" + httpResponse.getStatusLine().getStatusCode());
		String status = EntityUtils.toString(httpResponse.getEntity());
		return status;
	}
}
